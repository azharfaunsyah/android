package com.azharfaunsyah.kuis;

public class DataModel {
}
